/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador;



import com.mysql.jdbc.Connection;
import java.sql.SQLException;
import Modelo.Usuario;
import Modelo.conectar;

/**
 *
 * @author Usuario
 */
public class Usuario_controller{
   /* public static void InsertarUsuario(Connection con, String nombre, String pass) throws SQLException{
        Usuario nuevo = new Usuario(nombre, pass);
        conectar.Insertar(con, nuevo);
            
}*/
}
