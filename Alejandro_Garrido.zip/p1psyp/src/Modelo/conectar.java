
package Modelo;

import com.mysql.jdbc.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Properties;




/**
 *
 * @author Yo
 */
public class conectar{
    private static String servidor = "jdbc:mysql://localhost:3306/psyp1";
    private static String userName = "root";
    private static String password = "";
    private static String driver = "com.mysql.jdbc.Driver";
    private static Connection con;
    private String dbms ="mysql";
    private String serverName ="localhost";
    private String portNumber="3306";
    private String dbName="psyp1";
    
    
    public conectar() throws ClassNotFoundException{
        try{
          Class.forName(driver);
          con = (Connection) DriverManager.getConnection( servidor, userName , password );
          System.out.println("La conexion sa creao to pollua compae");
        }
        catch(SQLException e){
            System.out.println("La vin vieho sa liao to parda al crea la conesion");
        }
    }
    
    public Connection getConnection() throws SQLException {
         Connection conn = null;
    Properties connectionProps = new Properties();
    connectionProps.put("user", this.userName);
    connectionProps.put("password", this.password);

    if (this.dbms.equals("mysql")) {
        conn = (Connection) DriverManager.getConnection( 
                   "jdbc:" + this.dbms + "://" +
                   this.serverName +
                   ":" + this.portNumber + "/" + this.dbName,
                   connectionProps);
        System.out.println("Conectao a la basesilla de datajos esa");
    }
    
    return conn;
}
    
    public static ArrayList<Usuario> viewTable(Connection con, String dbName)
    throws SQLException {
    
    ArrayList<Usuario> vector = new ArrayList<Usuario>();
       
    Statement stmt = null;
    String query = "select Nombre, Pass " +
                   "from " + dbName + ".usuarios";
    try {
        
        stmt = con.createStatement();
        ResultSet rs = stmt.executeQuery(query);
        int i=0;
        while (rs.next()) {
            
            //String nombre = rs.getString("Nombre");
            //String pass = rs.getString("Pass");
            
            Usuario intro = new Usuario();
            intro.setUserName(rs.getString("Nombre"));
            intro.setPassword(rs.getString("Pass"));
            
            vector.add(intro);
//            System.out.println(vector.get(i).getUserName() + "\t" + vector.get(i).getPassword());
//            i++;
//            if (i>1){System.out.println(vector.get(i-1).getUserName() + "\t" + vector.get(i-1).getPassword());}
        }
    } catch (SQLException e ) {
        //JDBCTutorialUtilities.printSQLException(e);
        System.out.println("catch");
    } finally {
        if (stmt != null) { stmt.close(); }
    }
        
        return vector;
}
    
    public static void Insertar(Connection con, String nombre, String pass, String dbName)
    throws SQLException {
        Statement stmt = null;
       
        System.out.println(nombre + " , " + pass);
        try{
            
            stmt = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE ,ResultSet.CONCUR_UPDATABLE);
            
           ResultSet uprs =stmt.executeQuery(
           "SELECT * FROM " + dbName + ".usuarios");
           
           uprs.moveToInsertRow();
           uprs.updateString("Nombre", nombre);
           uprs.updateString("Pass", pass);
           
           uprs.insertRow();
           uprs.beforeFirst();
        }
        catch (SQLException e ) {
             System.out.println("El usuario no se inserto bien");
         }    
         finally {
         if (stmt != null) { stmt.close(); }
         }
    
    }
}
